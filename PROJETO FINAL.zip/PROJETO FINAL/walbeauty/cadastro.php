<!DOCTYPE html>

<?php
include_once "config.php";
require_once "funcoes.php";
include_once "BD_cadastro.php";
$u = new user;
?>

<head>
    <meta charset="utf-8" />
    <title>Cadastro</title>
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="Webflow" name="generator" />


    <link href="https://fonts.googleapis.com" rel="preconnect" />
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin="anonymous" />
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script type="text/javascript">
        WebFont.load({
            google: {
                families: ["Open Sans:300,300italic,400,400italic,600,600italic,700,700italic,800,800italic", "Roboto:300,regular,500"]
            }
        });
    </script>
    <link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
    <link href="https://assets-global.website-files.com/img/webclip.png" rel="apple-touch-icon" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="main" href="index.php">
    <link href="style.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="stylenav.css">
</head>

<body>
<div data-collapse="medium" data-animation="default" data-duration="400" data-easing="ease" data-easing2="ease"
        role="banner" class="navigation-bar w-nav">
        <div class="w-container"><a href="index.php" class="brand-link w-nav-brand">
                <h1 class="brand-text"><img class="img-logo" src="logo.png" alt="">WalBeauty</h1>
            </a>
            <nav role="navigation" class="navigation-menu w-nav-menu"><a href="index.php"
                    class="navigation-link w-nav-link"><i class="glyphicon glyphicon-home"></i> Inicio</a>
                    <a href="index.php#servicos" class="navigation-link w-nav-link"><i class="glyphicon glyphicon-check"></i> Serviços</a>
                    <a href="index.php#somos" class="navigation-link w-nav-link"><i class="glyphicon glyphicon-book"></i>
                    Quem Somos</a>
                <a href="loginPage.php" aria-current="page" class="navigation-link w-nav-link"><i
                        class="glyphicon glyphicon-log-in"></i> Entrar</a>
                        <a href="cadastro.php" class="navigation-link w-nav-link w--current"><i class="glyphicon glyphicon-user"></i> Cadastre-se</a>
            </nav>
            <div class="hamburger-button w-nav-button">
                <div class="w-icon-nav-menu"></div>
            </div>
        </div>
    </div>

    <div class="section">
        <h2 class="section-heading centered">Cadastro</h2>
        <div class="w-container cadastroForm">
            <div class="section-title-group">
            </div>
            <div class="form-wrapper w-form">
                <form id="email-form" name="email-form" data-name="Email Form" method="POST" class="form">
                    <input id="nome" type="text" class="form-field w-input" maxlength="50" name="nome" placeholder="Digite seu nome..." required=""/>
                    <input id="fone" type="text" class="form-field w-input" maxlength="14" pattern="\([0-9]{2}\)[0-9]{5}-[0-9]{4}" name="fone" data-name="fone" placeholder="Digite um número de telefone..." id="fone" required="" />

                    <input type="email" class="form-field w-input" maxlength="256" name="email" data-name="Email" placeholder="Digite seu e-mail..." id="email" required="" onblur="return validarEmail()" />

                    <input type="email" class="form-field w-input" maxlength="256" name="email2" data-name="Email2" placeholder="Confirme seu e-mail..." id="email2" required="" onblur="return validarEmail()"/>
                    <span id="msg2" style="color: red;"></span>

                    <input type="password" class="form-field w-input" maxlength="256" name="senha" data-name="senha" placeholder="Digite sua senha..." id="senha" required="" onblur="return validarSenha()" />

                    <input type="password" class="form-field w-input" maxlength="256" name="senha2" data-name="senha2" placeholder="Confirme sua senha..." id="senha2" required="" onblur="return validarSenha()" />
                    <span id="msg" style="color: red;"></span><br><br>


                    <input type="submit" value="Cadastrar" class="button full-width w-button" name="enviar" /><br>
                    <p>OU</p>
                    <a href="loginPage.php" class="cadastro">Faça login</a>
                </form>
            </div>
        </div>
    </div>

    <hr><br>

<div class="footer">
    <div class="w-container">
        <div class="w-row">
            <div class="spc w-col w-col-4">
                <h5>Sobre a walbeauty</h5>
                <p>Walbeauty é mais do que apenas um salão de beleza; é um santuário dedicado à elevação da beleza e ao cultivo do bem-estar. Fundado com a visão de proporcionar uma experiência transformadora, Walbeauty combina talento artístico com um compromisso inabalável com a satisfação do cliente.</p>
            </div>
            <div class="spc w-col w-col-4">
                <h5>Links uteis</h5><a href="https://segredosdomundo.r7.com/massagem-nos-pes/" class="footer-link">Benefícios milagrosos de uma massagem nos pés.</a><a href="https://www.barbanostra.com.br/artigo/id/25/curiosidades-sobre-massagem-relaxante"
                    class="footer-link">Curiosidades sobre Massagem</a><a href="https://makevida.com/design-de-sobrancelha/" class="footer-link">Design de sobrancelha: 10 curiosidades sobre a profissão</a><a href="https://joaodabeleza.com.br/blogs/blog-extensao-de-cilios/vantagens-da-extensao-de-cilios-na-autoestima-da-mulher" class="footer-link">Vantagens da extensão de cílios</a>
            </div>
            <div class="w-col w-col-4">
                <h5>social</h5>
                <div class="footer-link-wrapper w-clearfix"><img
                        src="https://assets-global.website-files.com/6567d83b7b7ab663a1c292fa/6567d83b7b7ab663a1c29397_social-18.svg"
                        width="20" alt="" class="info-icon" /><a href="https://twitter.com/i/flow/login" class="footer-link with-icon">Twitter</a>
                </div>
                <div class="footer-link-wrapper w-clearfix"><img
                        src="https://assets-global.website-files.com/6567d83b7b7ab663a1c292fa/6567d83b7b7ab663a1c29378_social-03.svg"
                        width="20" alt="" class="info-icon" /><a href="https://www.facebook.com/campaign/landing.php?&campaign_id=1661784632&extra_1=s%7Cc%7C320269324068%7Ce%7Cmfacebook%7C&placement=&creative=320269324068&keyword=mfacebook&partner_id=googlesem&extra_2=campaignid%3D1661784632%26adgroupid%3D63686352603%26matchtype%3De%26network%3Dg%26source%3Dnotmobile%26search_or_content%3Ds%26device%3Dc%26devicemodel%3D%26adposition%3D%26target%3D%26targetid%3Dkwd-301532274398%26loc_physical_ms%3D1001773%26loc_interest_ms%3D%26feeditemid%3D%26param1%3D%26param2%3D&gad_source=1&gclid=EAIaIQobChMI89rwwca4hAMV_1dIAB0EeApvEAAYASAAEgJ_nfD_BwE" class="footer-link with-icon">Facebook</a>
                </div>
                <div class="footer-link-wrapper w-clearfix"><img
                        src="https://assets-global.website-files.com/6567d83b7b7ab663a1c292fa/6567d83b7b7ab663a1c2935f_social-11.svg"
                        width="20" alt="" class="info-icon" /><a href="https://br.pinterest.com/"
                        class="footer-link with-icon">Pinterest</a></div>
                <div class="footer-link-wrapper w-clearfix"><img
                        src="https://icones.pro/wp-content/uploads/2021/03/logo-icone-tiktok-simbolo.png"
                        width="20" alt="" class="info-icon" /><a href="https://www.tiktok.com/login?lang=pt-BR&redirect_url=https%3A%2F%2Fwww.tiktok.com%2Fupload%3Flang%3Dpt-BR" class="footer-link with-icon">Tik Tok</a>
                </div>
                <div class="footer-link-wrapper w-clearfix"><img
                        src="https://assets-global.website-files.com/6567d83b7b7ab663a1c292fa/6567d83b7b7ab663a1c2936c_social-12.svg"
                        width="20" alt="" class="info-icon" /><a href="https://webflow.com/dashboard/login" class="footer-link with-icon">Webflow</a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="footer center">
    <div class="w-container">
        <div class="footer-text">Copyright WalSoft Inc.</div>
    </div>
</div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.inputmask/5.0.6/jquery.inputmask.min.js"></script>

    <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=6567d83b7b7ab663a1c292fa" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <script src="script.js" type="text/javascript"></script>

    <!-- MASCARA DE TELEFONE -->
    <script>
        $(document).ready(function() {
            $('#fone').inputmask('(99)99999-9999');
        });
    </script>

</body>

</html>