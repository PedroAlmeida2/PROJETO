<?php
require_once 'config.php';

if (isset($_POST['ID']) && !empty($_POST['ID'])) {
    $id = $_POST['ID'];

    try {
        // Atualiza o status do agendamento para 'cancelado'
        $stmt = $pdo->prepare("UPDATE agendamento SET status = 'cancelado' WHERE ID = ?");
        $stmt->execute([$id]);

        // Verifica se a atualização foi bem-sucedida
        if ($stmt->rowCount() > 0) {
            header("Location: agendamento.php");
        }
    } catch (PDOException $e) {
        echo "Erro ao atualizar o status do agendamento: " . $e->getMessage();
    }
}
