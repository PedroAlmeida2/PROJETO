﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_V1.Forms
{
    public partial class frmEditarCli : Form
    {
        banco bd = new banco();
        string sql;
        MySqlCommand cmd;
        string Id;
        public frmEditarCli()
        {
            InitializeComponent();
            buscarClientes();
        }

        private void LimparCampos()
        {
            tbNome.Text = "";
            tbCpf.Text = "";
            tbTel.Text = "";
            tbEmail.Text = "";
        }

        private void buscarClientes()
        {
            try
            {
                bd.abrirConn();

                string sql = "SELECT Id,NOME AS Nome, Tel AS Telefone, EMAIL AS Email, CPF FROM cliente";

                MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataTable dataTable = new DataTable();
                da.Fill(dataTable);
                dataGridView1.DataSource = dataTable;

                dataGridView1.ReadOnly = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao carregar dados: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.fecharConn();
            }
        }

        private void btnBuscar_Click_1(object sender, EventArgs e)
        {
            try
            {
                bd.abrirConn();

                // Construir a consulta SQL baseada nos campos preenchidos
                string sql = "SELECT Id, NOME AS Nome, Tel AS Telefone, EMAIL AS Email, CPF FROM cliente WHERE 1=1";

                if (!string.IsNullOrEmpty(tbNome.Text))
                    sql += " AND cliente.NOME LIKE @Nome";

                if (!string.IsNullOrEmpty(tbCpf.Text))
                    sql += " AND cliente.CPF = @Cpf";

                if (!string.IsNullOrEmpty(tbEmail.Text))
                    sql += " AND cliente.EMAIL LIKE @Email";

                if (!string.IsNullOrEmpty(tbTel.Text))
                    sql += " AND cliente.Tel LIKE @Telefone";

                MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                // Adicione parâmetros
                cmd.Parameters.AddWithValue("@Nome", "%" + tbNome.Text + "%");
                cmd.Parameters.AddWithValue("@Cpf", tbCpf.Text);
                cmd.Parameters.AddWithValue("@Email", "%" + tbEmail.Text + "%");
                cmd.Parameters.AddWithValue("@Telefone", "%" + tbTel.Text + "%");

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.SelectCommand = cmd;
                DataTable dataTable = new DataTable();
                da.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
                LimparCampos();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar clientes: {ex.Message}", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                bd.fecharConn();
            }
        }





        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                // Obtém o ID do cliente da célula clicada
                Id = dataGridView1.Rows[e.RowIndex].Cells["ID"].Value.ToString();

                // Obtém os valores das células da linha clicada
                string nome = dataGridView1.Rows[e.RowIndex].Cells["NOME"].Value.ToString();
                string telefone = dataGridView1.Rows[e.RowIndex].Cells["Telefone"].Value.ToString();
                string email = dataGridView1.Rows[e.RowIndex].Cells["Email"].Value.ToString();
                string cpf = dataGridView1.Rows[e.RowIndex].Cells["CPF"].Value.ToString();

                // Atribui os valores aos TextBoxes correspondentes
                tbNome.Text = nome;
                tbTel.Text = telefone;
                tbEmail.Text = email;
                tbCpf.Text = cpf;
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Verifica se o clique foi em uma célula válida
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Extrai os valores das células e os coloca nos TextBox correspondentes
                lblId.Text = row.Cells["id"].Value.ToString();
                tbNome.Text = row.Cells["nome"].Value.ToString();
                tbCpf.Text = row.Cells["cpf"].Value.ToString();
                tbTel.Text = row.Cells["telefone"].Value.ToString();
                tbEmail.Text = row.Cells["email"].Value.ToString();
                // Adicione mais TextBox conforme necessário para as colunas adicionais
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            // Verifica se o campo de ID não está vazio
            if (!string.IsNullOrEmpty(lblId.Text))
            {
                try
                {
                    // Converta o ID do texto para um número inteiro
                    if (int.TryParse(lblId.Text, out int id))
                    {
                        bd.abrirConn();


                        string sql = "UPDATE cliente SET nome=@nome, cpf=@cpf, email=@email, tel=@tel WHERE ID=@id";
                        MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@nome", tbNome.Text);
                        cmd.Parameters.AddWithValue("@cpf", tbCpf.Text);
                        cmd.Parameters.AddWithValue("@email", tbEmail.Text);
                        cmd.Parameters.AddWithValue("@tel", tbTel.Text);
                        cmd.ExecuteNonQuery();
                        bd.fecharConn();
                        MessageBox.Show("Cliente atualizado com sucesso!");
                        LimparCampos();
                        buscarClientes();
                    }
                    else
                    {
                        MessageBox.Show("Por favor, insira um ID válido.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao atualizar Cliente: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Por favor, insira o ID do Cliente que deseja atualizar.");
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Tem certeza?", "Excluindo dados!", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                bd.abrirConn();
                sql = "Delete from cliente where id=@id";
                MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@id", lblId.Text);
                cmd.ExecuteNonQuery();
                LimparCampos();
                buscarClientes();
                MessageBox.Show("Dados deletados!");

            }

            bd.fecharConn();
        }
    }
}
