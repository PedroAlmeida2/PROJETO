﻿using MySqlConnector;
using Projeto_V1.Forms;
using Projeto_V1.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_V1
{

    public partial class Principal : Form
    {
        public string nomeFuncionario;
        private bool isCollapsed;
        private bool isCollapsed2;
        private bool isCollapsed3;
        private bool isCollapsed4;
        public Form activeForm;
        public Button currentButton;
        banco bd = new banco();

        public Principal(string nome)
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.nomeFuncionario = nome;
        }



        private void Principal_Load(object sender, EventArgs e)
        {
            AtualizarQuantidadeAgendamentos();  
            AtualizarQuantidadeAgendamentosMes();
            AtualizarQuantidadeAgendamentosConcluidos();
            AtualizarQuantidadeAgendamentosConcluidosMes();
            AtualizarQuantidadeAgendamentosCancelados();
            AtualizarQuantidadeAgendamentosCanceladosMes();

            // Exemplo: exibir o nome do funcionário em algum controle do formulário
            nomeFuncionarioLogin.Text = $"{nomeFuncionario}";
        }

       


        private void AtualizarQuantidadeAgendamentos()
        {
            try
            {
                bd.abrirConn(); // Abrir conexão com o banco de dados

                string dataAtual = DateTime.Now.ToString("yyyy-MM-dd");
                string query = $"SELECT COUNT(*) FROM agendamento WHERE status = 'marcado' AND DATA_AGENDAMENTO = '{dataAtual}'";

                MySqlCommand cmd = new MySqlCommand(query, bd.conecta);
                int quantidadeAgendamentos = Convert.ToInt32(cmd.ExecuteScalar());

                numAgendamentos.Text = $"{quantidadeAgendamentos}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar dados: {ex.Message}");
            }
            finally
            {
                bd.fecharConn(); // Fechar conexão com o banco de dados
            }
        }
        private void AtualizarQuantidadeAgendamentosMes()
        {
            try
            {
                bd.abrirConn(); // Abrir conexão com o banco de dados

                DateTime dataAtual = DateTime.Now;
                DateTime primeiroDiaMes = new DateTime(dataAtual.Year, dataAtual.Month, 1);
                DateTime ultimoDiaMes = primeiroDiaMes.AddMonths(1).AddDays(-1);

                string mesAtual = dataAtual.ToString("yyyy-MM-dd");
                string ultimoDiaMesString = ultimoDiaMes.ToString("yyyy-MM-dd");

                string query = $"SELECT COUNT(*) FROM agendamento WHERE status = 'marcado' AND DATA_AGENDAMENTO BETWEEN '{mesAtual}' AND '{ultimoDiaMesString}'";

                MySqlCommand cmd = new MySqlCommand(query, bd.conecta);
                int quantidadeAgendamentosMes = Convert.ToInt32(cmd.ExecuteScalar());

                numAgendamentosMes.Text = $"{quantidadeAgendamentosMes}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar dados: {ex.Message}");
            }
            finally
            {
                bd.fecharConn(); // Fechar conexão com o banco de dados
            }
        }

        private void AtualizarQuantidadeAgendamentosConcluidos()
        {
            try
            {
                bd.abrirConn(); // Abrir conexão com o banco de dados


                string query = $"SELECT COUNT(*) FROM agendamento WHERE status = 'concluido'";

                MySqlCommand cmd = new MySqlCommand(query, bd.conecta);
                int quantidadeAgendamentosConcluidos = Convert.ToInt32(cmd.ExecuteScalar());

                numAgendamentosConcluidos.Text = $"{quantidadeAgendamentosConcluidos}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar dados: {ex.Message}");
            }
            finally
            {
                bd.fecharConn(); // Fechar conexão com o banco de dados
            }
        }

        private void AtualizarQuantidadeAgendamentosConcluidosMes()
        {
            try
            {
                bd.abrirConn(); // Abrir conexão com o banco de dados

                // Obtém o primeiro e o último dia do mês atual
                DateTime primeiroDiaDoMes = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                DateTime ultimoDiaDoMes = primeiroDiaDoMes.AddMonths(1).AddDays(-1);

                // Formata as datas para o formato do banco de dados (assumindo que o campo 'data_agendamento' é usado para verificar a data)
                string dataInicioFormatada = primeiroDiaDoMes.ToString("yyyy-MM-dd");
                string dataFimFormatada = ultimoDiaDoMes.ToString("yyyy-MM-dd");

                string query = $"SELECT COUNT(*) FROM agendamento WHERE status = 'concluido' AND data_agendamento BETWEEN '{dataInicioFormatada}' AND '{dataFimFormatada}'";

                MySqlCommand cmd = new MySqlCommand(query, bd.conecta);
                int quantidadeAgendamentosConcluidosMes = Convert.ToInt32(cmd.ExecuteScalar());

                numAgendamentosConcluidosMes.Text = $"{quantidadeAgendamentosConcluidosMes}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar dados: {ex.Message}");
            }
            finally
            {
                bd.fecharConn(); // Fechar conexão com o banco de dados
            }
        }


        private void AtualizarQuantidadeAgendamentosCancelados()
        {
            try
            {
                bd.abrirConn(); // Abrir conexão com o banco de dados


                string query = $"SELECT COUNT(*) FROM agendamento WHERE status = 'cancelados'";

                MySqlCommand cmd = new MySqlCommand(query, bd.conecta);
                int quantidadeAgendamentosCancelados = Convert.ToInt32(cmd.ExecuteScalar());

                numAgendamentosCancelados.Text = $"{quantidadeAgendamentosCancelados}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar dados: {ex.Message}");
            }
            finally
            {
                bd.fecharConn(); // Fechar conexão com o banco de dados
            }
        }

        private void AtualizarQuantidadeAgendamentosCanceladosMes()
        {
            try
            {
                bd.abrirConn(); // Abrir conexão com o banco de dados

                // Obtém o primeiro e o último dia do mês atual
                DateTime primeiroDiaDoMes = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
                DateTime ultimoDiaDoMes = primeiroDiaDoMes.AddMonths(1).AddDays(-1);

                // Formata as datas para o formato do banco de dados (assumindo que o campo 'data_agendamento' é usado para verificar a data)
                string dataInicioFormatada = primeiroDiaDoMes.ToString("yyyy-MM-dd");
                string dataFimFormatada = ultimoDiaDoMes.ToString("yyyy-MM-dd");

                string query = $"SELECT COUNT(*) FROM agendamento WHERE status = 'cancelado' AND data_agendamento BETWEEN '{dataInicioFormatada}' AND '{dataFimFormatada}'";

                MySqlCommand cmd = new MySqlCommand(query, bd.conecta);
                int quantidadeAgendamentosCanceladosMes = Convert.ToInt32(cmd.ExecuteScalar());

                numAgendamentosCanceladosMes.Text = $"{quantidadeAgendamentosCanceladosMes}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao buscar dados: {ex.Message}");
            }
            finally
            {
                bd.fecharConn(); // Fechar conexão com o banco de dados
            }
        }


        public void ActivateButton(object btnSender)
        {
            if (currentButton != (Button)btnSender)
            {
                currentButton = (Button)btnSender;
            }
        }


        public void OpenChildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            ActivateButton(btnSender);
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelAgenda.Controls.Add(childForm);
            this.panelAgenda.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
        private void CloseOtherDropdowns(int currentDropdown, bool isSameButton)
        {
            int alturaPainel = 86;
            int alturaPainel2 = 167;
            int alturaPainel3 = 167;
            int alturaPainel4 = 167;

            if (currentDropdown != 1 && (!isCollapsed || !isSameButton))
            {
                timerAgenda.Stop();
                isCollapsed = true;
                btAgenda.Image = Resources.Expand_Arrow_20px;
                panelDropDown.Height -= alturaPainel;
                panelDropDown2.Top = panelDropDown.Bottom;
                panelDropDown3.Top = panelDropDown2.Bottom;
                panelDropDown4.Top = panelDropDown3.Bottom;
            }

            if (currentDropdown != 2 && (!isCollapsed2 || !isSameButton))
            {
                timerFuncionarios.Stop();
                isCollapsed2 = true;
                btFuncionario.Image = Resources.Expand_Arrow_20px;
                panelDropDown2.Height -= alturaPainel2;
                panelDropDown3.Top = panelDropDown2.Bottom;
                panelDropDown4.Top = panelDropDown3.Bottom;
            }

            if (currentDropdown != 3 && (!isCollapsed3 || !isSameButton))
            {
                timerClientes.Stop();
                isCollapsed3 = true;
                btCliente.Image = Resources.Expand_Arrow_20px;
                panelDropDown3.Height -= alturaPainel3;
                panelDropDown4.Top = panelDropDown3.Bottom;
            }

            if (currentDropdown != 4 && (!isCollapsed4 || !isSameButton))
            {
                timerServicos.Stop();
                isCollapsed4 = true;
                btServicos.Image = Resources.Expand_Arrow_20px;
                panelDropDown4.Height -= alturaPainel4;
            }
        }

        private void timerRelogio_Tick_1(object sender, EventArgs e)
        {
            this.hora.Text = DateTime.Now.ToString("HH:mm:ss");
            this.data.Text = DateTime.Today.ToString("dd/MM/yyyy");
        }

        private void btAgenda_Click_1(object sender, EventArgs e)
        {
            CloseOtherDropdowns(1, true);
            timerAgenda.Start();
        }

        private void btFuncionario_Click_1(object sender, EventArgs e)
        {

            CloseOtherDropdowns(2, true);
            timerFuncionarios.Start();
        }

        private void btClientes_Click_1(object sender, EventArgs e)
        {
            CloseOtherDropdowns(3, true);
            timerClientes.Start();
        }

        private void btServicos_Click_1(object sender, EventArgs e)
        {
            CloseOtherDropdowns(4, true);
            timerServicos.Start();
        }

        private void timerAgenda_Tick_1(object sender, EventArgs e)
        {
            int incremento = 10;
            if (isCollapsed)
            {
                btAgenda.Image = Resources.Collapse_Arrow_20px;
                panelDropDown.Height += incremento;
                panelDropDown2.Top = panelDropDown.Bottom;
                panelDropDown3.Top = panelDropDown2.Bottom;
                panelDropDown4.Top = panelDropDown3.Bottom;
                if (panelDropDown.Size == panelDropDown.MaximumSize)
                {
                    timerAgenda.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                btAgenda.Image = Resources.Expand_Arrow_20px;
                panelDropDown.Height -= incremento;
                panelDropDown2.Top = panelDropDown.Bottom;
                panelDropDown3.Top = panelDropDown2.Bottom;
                panelDropDown4.Top = panelDropDown3.Bottom;
                if (panelDropDown.Size == panelDropDown.MinimumSize)
                {
                    timerAgenda.Stop();
                    isCollapsed = true;
                }
            }
        }


        private void timerFuncionarios_Tick_1(object sender, EventArgs e)
        {
            int incremento = 10;

            if (isCollapsed2)
            {
                btFuncionario.Image = Resources.Collapse_Arrow_20px;
                panelDropDown2.Height += incremento;
                panelDropDown3.Top = panelDropDown2.Bottom;
                panelDropDown4.Top = panelDropDown3.Bottom;
                if (panelDropDown2.Size == panelDropDown2.MaximumSize)
                {
                    timerFuncionarios.Stop();
                    isCollapsed2 = false;
                }
            }
            else
            {
                btFuncionario.Image = Resources.Expand_Arrow_20px;
                panelDropDown2.Height -= incremento;
                panelDropDown3.Top = panelDropDown2.Bottom;
                panelDropDown4.Top = panelDropDown3.Bottom;
                if (panelDropDown2.Size == panelDropDown2.MinimumSize)
                {
                    timerFuncionarios.Stop();
                    isCollapsed2 = true;
                }
            }
        }


        private void timerClientes_Tick_1(object sender, EventArgs e)
        {
            int incremento = 10;

            if (isCollapsed3)
            {
                btCliente.Image = Resources.Collapse_Arrow_20px;
                panelDropDown3.Height += incremento;
                panelDropDown4.Top = panelDropDown3.Bottom;
                if (panelDropDown3.Size == panelDropDown3.MaximumSize)
                {
                    timerClientes.Stop();
                    isCollapsed3 = false;
                }
            }
            else
            {
                btCliente.Image = Resources.Expand_Arrow_20px;
                panelDropDown3.Height -= incremento;
                panelDropDown4.Top = panelDropDown3.Bottom;
                if (panelDropDown3.Size == panelDropDown3.MinimumSize)
                {
                    timerClientes.Stop();
                    isCollapsed3 = true;
                }
            }
        }


        private void timerServicos_Tick_1(object sender, EventArgs e)
        {
            int incremento = 10;

            if (isCollapsed4)
            {
                btServicos.Image = Resources.Collapse_Arrow_20px;
                panelDropDown4.Height += incremento;
                if (panelDropDown4.Size == panelDropDown4.MaximumSize)
                {
                    timerServicos.Stop();
                    isCollapsed4 = false;
                }
            }
            else
            {
                btServicos.Image = Resources.Expand_Arrow_20px;
                panelDropDown4.Height -= incremento;
                if (panelDropDown4.Size == panelDropDown4.MinimumSize)
                {
                    timerServicos.Stop();
                    isCollapsed4 = true;
                }
            }
        }

        private void btAgendaEditar_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.frmEditarAgenda(), sender);
        }

        private void btAgendaAgendamento_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.frmAgendamento(), sender);
        }

        private void btFuncionarioCadastro_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.frmCadastroFunc(), sender);
        }

        private void btFuncionarioEditar_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.frmEditarFunc(), sender);
        }

        private void btClienteCadastro_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.frmCadastroCli(), sender);
        }

        private void btClienteEditar_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.frmEditarCli(), sender);
        }

        private void btServicoCadastro_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.frmCadastroServicos(), sender);
        }

        private void btServicoEditar_Click(object sender, EventArgs e)
        {
            OpenChildForm(new Forms.frmEditarServicos(), sender);
        }

        private void numAgendamentos_Click(object sender, EventArgs e)
        {

        }

        private void LOGOUT_Click(object sender, EventArgs e)
        {
            // Esconde o frmPrincipal
            this.Hide();

            // Exibe o frmLogin
            frmLogin loginForm = new frmLogin();
            if (loginForm.ShowDialog() == DialogResult.OK)
            {
                // Obter os dados atualizados após o login
                string novoNomeFuncionario = loginForm.ObterNomeFuncionarioLogado();

                // Atualiza informações no frmPrincipal
                AtualizarDadosFrmPrincipal(novoNomeFuncionario);

                // Mostra novamente o frmPrincipal
                this.Show();
            }
            else
            {
                // Se não for DialogResult.OK, mostra novamente o frmPrincipal
                this.Show();
            }
        }

        private void AtualizarDadosFrmPrincipal(string novoNomeFuncionario)
        {
            nomeFuncionarioLogin.Text = novoNomeFuncionario;
        }

        private void numAgendamentosMes_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AtualizarQuantidadeAgendamentos();
            AtualizarQuantidadeAgendamentosMes();
            AtualizarQuantidadeAgendamentosConcluidos();
            AtualizarQuantidadeAgendamentosConcluidosMes();
            AtualizarQuantidadeAgendamentosCancelados();
            AtualizarQuantidadeAgendamentosCanceladosMes();
        }
    }
}
