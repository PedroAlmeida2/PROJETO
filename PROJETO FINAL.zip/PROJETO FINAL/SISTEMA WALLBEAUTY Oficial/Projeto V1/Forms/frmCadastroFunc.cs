﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace Projeto_V1.Forms
{
    public partial class frmCadastroFunc : Form
    {
        banco bd = new banco(); //variavel usada para consumir a classe banco criada previamente
        string sql; //será usado para usar os comandos do MySql
        MySqlCommand cmd; //esta variavel está consumindo a classe MySqlCommand que será usada para EXECUTAR os comandos do MySql
        string Id;
        public frmCadastroFunc()
        {
            InitializeComponent();
            tbSenha.PasswordChar = '*';
        }


        // Função para criptografar a senha usando SHA256
        private string CriptografarSenha(string senha)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // Converter a senha para um array de bytes
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(senha));

                // Converter os bytes para uma string hexadecimal
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        private void tbSenha_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void btnInsert_Click_1(object sender, EventArgs e)
        {
            bd.abrirConn();
            if (CamposObrigatoriosPreenchidos())
            {
                try
                {
                    string senhaCriptografada = CriptografarSenha(tbSenha.Text); // Criptografar a senha antes de enviar ao banco de dados

                    string sql = "INSERT INTO funcionario (NOME,SOBRENOME,CPF,EMAIL,TELEFONE,CEP,SALARIO,senha,DATA_NASCIMENTO,DATA_CONTRATACAO) VALUES (@nome, @sobrenome, @cpf, @email, @telefone, @cep, @salario, @senha, @data_nascimento, @data_contratacao)";
                    MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
                    cmd.Parameters.AddWithValue("@nome", tbNome.Text);
                    cmd.Parameters.AddWithValue("@sobrenome", tbSobrenome.Text);
                    cmd.Parameters.AddWithValue("@cpf", tbCpf.Text);
                    cmd.Parameters.AddWithValue("@email", tbEmail.Text);
                    cmd.Parameters.AddWithValue("@telefone", tbTelefone.Text);
                    cmd.Parameters.AddWithValue("@cep", tbCep.Text);
                    cmd.Parameters.AddWithValue("@salario", tbSalario.Text);
                    cmd.Parameters.AddWithValue("@senha", senhaCriptografada); // Usar a senha criptografada
                    cmd.Parameters.AddWithValue("@data_nascimento", dateNascimento.Value);
                    cmd.Parameters.AddWithValue("@data_contratacao", dateAdmissao.Value);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Dados inseridos");
                    LimparCampos();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao inserir dados: " + ex.Message);
                }
                finally
                {
                    bd.fecharConn();
                }
            }
            else
            {
                MessageBox.Show("Preencha todos os campos obrigatórios.", "Campos obrigatórios não preenchidos", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void LimparCampos()
        {
            tbNome.Text = "";
            tbSobrenome.Text = "";
            tbCpf.Text = "";
            tbEmail.Text = "";
            tbTelefone.Text = "";
            tbCep.Text = "";
            tbSenha.Text = "";
            tbSalario.Text = "";
        }

        private bool CamposObrigatoriosPreenchidos()
        {
            // Verifica se todos os campos obrigatórios estão preenchidos
            return !string.IsNullOrWhiteSpace(tbNome.Text) &&
                   !string.IsNullOrWhiteSpace(tbSobrenome.Text) &&
                   !string.IsNullOrWhiteSpace(tbCpf.Text) &&
                   !string.IsNullOrWhiteSpace(tbEmail.Text) &&
                   !string.IsNullOrWhiteSpace(tbTelefone.Text) &&
                   !string.IsNullOrWhiteSpace(tbSenha.Text) &&
                   !string.IsNullOrWhiteSpace(tbCep.Text) &&
                   !string.IsNullOrWhiteSpace(tbSalario.Text) &&
                   dateNascimento.Value != DateTime.MinValue && // Garante que a data de nascimento foi selecionada
                   dateAdmissao.Value != DateTime.MinValue; // Garante que a data de admissão foi selecionada
        }

    }
}
