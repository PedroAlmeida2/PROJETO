﻿using MySqlConnector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1.Forms
{
    public partial class frmEditarAgenda : Form
    {
        banco bd = new banco();
        string sql;
        MySqlCommand cmd;

        public frmEditarAgenda()
        {
            InitializeComponent();
            busca();
            FillCliente();
            FillServico();
            FillFuncionario();
        }

        //------------------------------------------------------------funções---------------------------------------------------------
        private void busca()
        {
            bd.abrirConn();
            sql = "SELECT Agendamento.ID as ID, Cliente.NOME AS Cliente, Agendamento.CLIENTE_NOME as ClienteSite, Servico.NOME AS Serviço, Funcionario.NOME AS Funcionário, Agendamento.DATA_AGENDAMENTO as Data, Servico.PRECO as Preço, Agendamento.STATUS as Status " +
                  "FROM agendamento " +
                  "INNER JOIN cliente ON Agendamento.FK_CLIENTE_ID = cliente.id " +
                  "INNER JOIN servico ON Agendamento.FK_SERVICO_ID = servico.id " +
                  "INNER JOIN funcionario ON Agendamento.FUNCIONARIO_ID = funcionario.id WHERE STATUS = 'marcado'";

            cmd = new MySqlCommand(sql, bd.conecta);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
        }


        private void FillFuncionario()
        {
            bd.abrirConn();
            sql = "select nome from funcionario";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbFunc.DataSource = dt;
                cbFunc.DisplayMember = "nome";
            }

        }
        private void FillServico()
        {
            bd.abrirConn();
            sql = "select nome from servico";
            cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);
            {
                cbServico.DataSource = dt;
                cbServico.DisplayMember = "nome";
            }
        }


        private void FillCliente()
        {
            bd.abrirConn();
            string sql = "select nome from cliente";
            MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

            MySqlDataAdapter da = new MySqlDataAdapter();
            da.SelectCommand = cmd;
            DataTable dt = new DataTable();
            da.Fill(dt);

            cbCliente.DataSource = dt.Copy(); // Copia o DataTable para cbCliente
            cbCliente.DisplayMember = "nome";

            cbBusca.DataSource = dt.Copy(); // Copia o DataTable para cbBusca
            cbBusca.DisplayMember = "nome";
        }





        //-----------------------------------------------------crud do form----------------------------------------------------------

        //buscar
        private void btnSelect_Click_1(object sender, EventArgs e)
        {
            bd.abrirConn();
            sql = "SELECT Agendamento.Id as ID, Cliente.NOME AS Cliente, Servico.NOME AS Serviço, Agendamento.DATA_AGENDAMENTO as Data, Funcionario.NOME AS Funcionário, Servico.PRECO as Preço, Agendamento.STATUS as Status " +
                  "FROM agendamento " +
                  "INNER JOIN cliente ON Agendamento.FK_CLIENTE_ID = cliente.id " +
                  "INNER JOIN servico ON Agendamento.FK_SERVICO_ID = servico.id " +
                  "INNER JOIN funcionario ON Agendamento.FUNCIONARIO_ID = funcionario.id " +
                  "WHERE cliente.NOME = @BuscaCliente";

            cmd = new MySqlCommand(sql, bd.conecta);
            cmd.Parameters.AddWithValue("@BuscaCliente", cbBusca.Text);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.SelectCommand = cmd;
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            dataGridView1.DataSource = dataTable;

        }


        //atualizar dados
        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            bd.abrirConn();

            DateTime dataSelecionada = dtAgendamento.Value.Date; // Obtém a data selecionada
            string horaSelecionada = cbHora.SelectedItem.ToString(); // Obtém a hora selecionada
            DateTime dataHoraSelecionada = dataSelecionada.Add(TimeSpan.Parse(horaSelecionada));

            // Verifica se já existe um agendamento com os mesmos dados
            if (AgendamentoExistente())
            {
                MessageBox.Show("Já existe um agendamento com esses dados.");
                return; // Sai do método para evitar a inserção
            }

            // Atualiza o agendamento
            string sqlAtualizar = @"
    UPDATE agendamento
    SET agendamento.FUNCIONARIO_ID = (SELECT f.ID FROM funcionario f WHERE f.nome = @Func),
        agendamento.FK_CLIENTE_ID = (SELECT c.ID FROM cliente c WHERE c.nome = @Cliente),
        agendamento.FK_SERVICO_ID = (SELECT s.ID FROM servico s WHERE s.nome = @Serv),           
        agendamento.DATA_AGENDAMENTO = @DataAgenda 
    WHERE agendamento.ID = @Id";

            DataGridViewRow row = dataGridView1.SelectedRows[0];
            MySqlCommand cmdAtualizar = new MySqlCommand(sqlAtualizar, bd.conecta);
            cmdAtualizar.Parameters.AddWithValue("@Func", cbFunc.Text);
            cmdAtualizar.Parameters.AddWithValue("@Cliente", cbCliente.Text);
            cmdAtualizar.Parameters.AddWithValue("@Serv", cbServico.Text);
            cmdAtualizar.Parameters.AddWithValue("@DataAgenda", dataHoraSelecionada);
            cmdAtualizar.Parameters.AddWithValue("@Id", row.Cells["ID"].Value);

            cmdAtualizar.ExecuteNonQuery();
            MessageBox.Show("Agendamento atualizado com sucesso!");
            busca();
        }



        //deletar
        private void btnCancel_Click_1(object sender, EventArgs e)
        {

            DialogResult dialogResult = MessageBox.Show("Tem certeza que deseja cancelar o serviço?", "Serviço cancelado.", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes && lbStatus.Text == "Cancelado")
            {
                MessageBox.Show("O serviço selecionado já foi cancelado.");
            }
            else
            {
                bd.abrirConn();
                sql = "update agendamento set STATUS= 'Cancelado' where id=@id";
                cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@id", lbId.Text);
                cmd.ExecuteNonQuery();
                busca();
            }
        }

        private void btnConcluir_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("O serviço selecionado será dado como concluído, continuar?", "Serviço concluído.", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes && lbStatus.Text == "Concluído")
            {
                MessageBox.Show("O serviço selecionado já foi concluído.");
            }
            else
            {
                bd.abrirConn();
                sql = "update agendamento set STATUS= 'Concluído' where id=@id";
                cmd = new MySqlCommand(sql, bd.conecta);
                cmd.Parameters.AddWithValue("@id", lbId.Text);
                cmd.ExecuteNonQuery();
                busca();
            }
        }

        //reseta o datagridview, voltando a mostrar todos os agendamentos (caso tenha apertado o "buscar" e queira voltar atrás)
        private void btnReset_Click_1(object sender, EventArgs e)
        {
            busca();

        }


        private bool AgendamentoExistente()
        {
            string sqlVerificar = @"
SELECT COUNT(*) 
FROM agendamento 
WHERE FUNCIONARIO_ID = (SELECT ID FROM funcionario WHERE nome = @Funcionario LIMIT 1) 
AND FK_CLIENTE_ID = (SELECT ID FROM cliente WHERE nome = @Cliente LIMIT 1) 
AND FK_SERVICO_ID = (SELECT ID FROM servico WHERE nome = @Servico LIMIT 1) 
AND DATA_AGENDAMENTO = @Data";

            using (MySqlCommand cmdVerificar = new MySqlCommand(sqlVerificar, bd.conecta))
            {
                cmdVerificar.Parameters.AddWithValue("@Funcionario", cbFunc.Text);
                cmdVerificar.Parameters.AddWithValue("@Cliente", cbCliente.Text);
                cmdVerificar.Parameters.AddWithValue("@Servico", cbServico.Text);
                cmdVerificar.Parameters.AddWithValue("@Data", dtAgendamento.Value.Date);
                cmdVerificar.Parameters.AddWithValue("@Hora", cbHora.Text);

                int count = Convert.ToInt32(cmdVerificar.ExecuteScalar());

                return count > 0;
            }
        }


        private void frmEditarAgenda_Load(object sender, EventArgs e)
        {



        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                // Preenche os ComboBoxes com os dados do banco de dados
                FillServico();
                FillFuncionario();
                FillCliente();

                // Atualiza os ComboBoxes com base nos dados da linha selecionada
                string servico = row.Cells["SERVIÇO"].Value.ToString();
                int indexServico = cbServico.FindStringExact(servico);
                cbServico.Enabled = true;
                cbServico.SelectedIndex = indexServico;

                string funcionario = row.Cells["FUNCIONÁRIO"].Value.ToString();
                int indexFuncionario = cbFunc.FindStringExact(funcionario);
                cbFunc.Enabled = true;
                cbFunc.SelectedIndex = indexFuncionario;

                string cliente = row.Cells["CLIENTE"].Value.ToString();
                int indexCliente = cbCliente.FindStringExact(cliente);
                cbCliente.Enabled = true;
                cbCliente.SelectedIndex = indexCliente;

                string valor = row.Cells["PREÇO"].Value.ToString();
                tbValor.Text = valor;

                // Atualiza as labels com os valores das colunas "ID" e "Status"
                lbId.Text = row.Cells["ID"].Value.ToString();
                lbStatus.Text = row.Cells["Status"].Value.ToString();

                // Obtém a data e hora do agendamento a partir da coluna "Data"
                string dataHoraAgendamento = row.Cells["Data"].Value.ToString();
                DateTime dataHora = DateTime.Parse(dataHoraAgendamento);

                // Habilita o ComboBox de hora e preenche com a hora do agendamento
                cbHora.Enabled = true;
                cbHora.Items.Clear();
                cbHora.Items.Clear();
                foreach (var horario in ObterHorariosDisponiveis())
                {
                    cbHora.Items.Add(horario);
                    cbHora.SelectedIndex = 0;
                }


                // Habilita o DateTimePicker de data e atualiza com a data do agendamento
                dtAgendamento.Enabled = true;
                dtAgendamento.Value = dataHora;
            }
        }



        private List<string> ObterHorariosDisponiveis()
        {
            // Consulta o banco de dados para obter os horários já agendados
            List<string> horariosAgendados = ConsultarHorariosAgendados();

            // Lista de horários disponíveis para o agendamento
            List<string> horariosDisponiveis = new List<string>();

            // Adiciona todos os horários possíveis que não estão agendados
            string[] todosHorarios = { "07:00:00", "08:00:00", "09:00:00", "10:00:00", "11:00:00", "13:00:00", "14:00:00", "15:00:00", "16:00:00", "17:00:00", "18:00:00", "19:00:00" };
            foreach (var horario in todosHorarios)
            {
                if (!horariosAgendados.Contains(horario))
                {
                    horariosDisponiveis.Add(horario);
                }
            }

            return horariosDisponiveis;
        }

        private List<string> ConsultarHorariosAgendados()
        {
            // Consulta o banco de dados para obter os horários já agendados para a data selecionada
            List<string> horariosAgendados = new List<string>();

            bd.abrirConn();
            string sql = "SELECT TIME(Data_agendamento) AS Hora FROM Agendamento WHERE DATE(Data_agendamento) = @Data";
            MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);
            cmd.Parameters.AddWithValue("@Data", dtAgendamento.Value.Date);

            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string horaAgendada = reader["Hora"].ToString();
                    horariosAgendados.Add(horaAgendada);
                }
            }

            return horariosAgendados;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}