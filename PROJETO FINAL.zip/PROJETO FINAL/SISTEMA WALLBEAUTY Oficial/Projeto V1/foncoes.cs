﻿using MySqlConnector;
using Projeto_V1.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Projeto_V1
{



    public class Funcoes
    {
        public static void InserirCliente(string nome, string cpf, string tel, string email, string senha)
        {
            banco bd = new banco();
            string sql;

            try
            {
                bd.abrirConn();

                if (string.IsNullOrWhiteSpace(nome) && string.IsNullOrWhiteSpace(cpf))
                {
                    MessageBox.Show("Insira dados válidos.");
                }
                else
                {
                    // Criptografando a senha em MD5
                    string senhaCriptografada = CriptografarMD5(senha);

                    sql = "insert into cliente (nome, cpf, tel, email, senha) values(@nome, @cpf, @tel, @email, @senha)";
                    MySqlCommand cmd = new MySqlCommand(sql, bd.conecta);

                    cmd.Parameters.AddWithValue("@nome", nome);
                    cmd.Parameters.AddWithValue("@cpf", cpf);
                    cmd.Parameters.AddWithValue("@tel", tel);
                    cmd.Parameters.AddWithValue("@email", email);
                    cmd.Parameters.AddWithValue("@senha", senhaCriptografada);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Dados inseridos");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao inserir dados: " + ex.Message);
            }
            finally
            {
                bd.fecharConn();
            }
        }

        private static string CriptografarMD5(string input)
        {
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("x2"));
                }

                return sb.ToString();
            }
        }
    }





}
