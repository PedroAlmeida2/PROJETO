﻿using Projeto_V1;
using Projeto_V1.Forms;
using System;
using System.Windows.Forms;

static class Program
{
    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);

        frmLogin loginForm = new frmLogin();
        if (loginForm.ShowDialog() == DialogResult.OK)
        {
            string nomeFuncionario = loginForm.ObterNomeFuncionarioLogado();
            loginForm.Hide(); // Oculta o formulário de login
            Application.Run(new Principal(nomeFuncionario));
            loginForm.Close(); // Fecha o formulário de login quando o formulário principal é fechado
        }
    }
}
